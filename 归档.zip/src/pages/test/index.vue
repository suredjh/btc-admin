<template>
    <h1>这里的数据 都为假的数据、图标部分目前没有图片 暂时没有加上去 后续有真实数据的时候 在完善</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>
