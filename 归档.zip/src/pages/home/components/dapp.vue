<template>
    <h1>this is test about home</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>
