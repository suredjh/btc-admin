<template>
    <div>
        <!-- 分类 -->
        <div class="classify">
            <div class="title">分类</div>
            <ul class="lists">
                <li v-for="item in clists" :key="item" @click="activeInfo = item" :class="['list', {'active': item == activeInfo}]">{{item}}</li>
            </ul>
        </div>
        <!-- 列表 -->
        <div class="table-titles">
            <div class="title-first">项目</div>
            <div>模块</div>
            <div>市值</div>
            <div>排名</div>
            <div>成立时间</div>
        </div>
        <div class="tlist" v-for="item in infoLists" :key="item.id" @click="checkDetailHandle(item.id)">
            <div class="tinfo">
                <div class="img"><img :src="item.img" /></div>
                <div class="info">no value{{item.name}}</div>
            </div>
            <div>{{item.category}}</div>
            <div>{{item.marketValue}}</div>
            <div>{{item.rank}}</div>
            <div>{{item.releaseDate}}</div>
        </div>
        <div :style="{padding: '20px 0', textAlign: 'center'}">
            <el-pagination
            background
            @current-change="getDataListHandle"
            :current-page.sync="page"
            layout="prev, pager, next"
            :total="total">
            </el-pagination>
        </div>
    </div>
</template>

<script>
export default {
    data () {
        return {
            infoLists: [],
            page: 1,
            total: 0,
            pageSize: 20,
            ctype: 1,
            activeInfo: '全部',
            clists: ["全部", "基础链", "生物/医疗健康", "交易平台币", "全部1", "基础链1", "生物/医疗健康1", "交易平台币1", "全部2", "基础链2", "生物/医疗健康2", "交易平台币2", "全部3", "基础链3", "生物/医疗健康3", "交易平台币3", "全部4", "基础链4", "生物/医疗健康4", "交易平台币4",]
        }
    },
    created() {
        this.getDataListHandle(this.page);
        // this.$http('/projects').then(res => {
        //     // this.infoLists = res;
        // })
        // console.log(this.$http);
    },
    methods: {
        getDataListHandle (page = 1) {
            let params = {
                categories: this.categories || '',
                page,
                limit: this.pageSize
            }
            this.$http('/projects', { params}).then(res => {
                this.infoLists = res;
                this.total = res.length;
            })
        },
        checkDetailHandle (id) {
            this.$router.push({ path: `/detail/${id}`});
        }
    }
}
</script>
<style lang="scss" scoped>
.table-titles {
    color: #999999;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    text-align: center;
    & > div {
        flex: 1;
    }
    .title-first {
        min-width:  400px;
        padding-left: 20px;
        text-align: left;
    }
}
.tlist {
    color: #999999;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    height: 80px;
    background: #ffffff;
    box-shadow: 0 0 5px #cccccc;
    margin-top: 5px;
    & > div {
        flex: 1;
        &:first-child {
            text-align: left;
            min-width: 400px;
            padding-left: 20px;
        }
    } 
    img {
        width: 100%;
        height: 100%;
    }
}
.tinfo {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    .img {
        width: 52px;
        height: 52px;
        background: red;
    }
    .info {
        flex: 1;
        padding-left: 5px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }
}
.classify {
    width: 100%;
    overflow: hidden;
    padding: 15px;
    background: #ffffff;
    box-shadow: 0 0 5px #cccccc;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    .title {
        color: #000000;
        font-weight: bold;
    }
}
.lists {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    flex-wrap: wrap;
    cursor: pointer;
    .list {
        width: 130px;
        color: #999999;
        padding: 5px 0;
        &.hover, &.active {
            color: blueviolet;
        }
    }
}
</style>
